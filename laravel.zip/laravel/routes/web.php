<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. 
|
*/

Route::get('/', 'PagesController@index')->name('index');

Route::get('/recipes', 'PagesController@recipes')->name('recipes');

Route::get('/calendar', 'PagesController@calendar')->name('calendar');

Route::get('recipes/{recipeid}', 'RecipeController@recipe')->name('recipe');

Route::post('recipes/{recipeid}/comment', 'CommentController@store')->name('commentrecipe');

Route::get('/home', 'HomeController@index')->name('home');

Route::post('delete/{id}', 'CommentController@delete')->name('delete');

Route::get('/login', 'PagesController@login');

Route::get('recipes/{recipeid}/comment', 'CommentController@get');

Auth::routes();