
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">  
  {{ HTML::style('css/mystyle.css'); }}

<div class="detailBox">
    <div class="titleBox">
      <label>Comments </label>        
    </div>

    <div class="actionBox">
        {{ Form::open(array('url'=>'/comment', 'method' => 'post' , 'class' => 'form-inline' )) }}        
          <div class="form-group" style="width:100%; position:relative">                             
              {{ Form::textarea('commentText', null, ['class' => 'form-control', 'placeholder' => 'Add your comment', 'rows' => '4']) }}
          </div>
          <div class="form-group">                
              {{ Form::submit('Post Comment', array('class' => 'btn btn-block btn-primary' , 'style' => 'width:220px')) }}
          </div>
        {{ Form::close() }}         
    </div>
</div>

<div class="valid">
  @if ($errors->any())      
    @foreach( $errors->all() as $message )
      <div class="alert alert-info">
        <strong>Alert!</strong> {{ $message }}
      </div>  
    @endforeach        
  @endif
</div>