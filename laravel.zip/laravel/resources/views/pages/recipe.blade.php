@extends('layouts.app')
@section('content')

<div class="div3">
						<br>
						<br>
						<h2>{{ $recipe }}</h2>
						<br>

			
			<ul id="navcontainer"><li>{{ $ingrediens }}</li></ul>
			
						
						<br>
						<br>
						<h2>Description:</h2>
						<br>
			{{ $description }}
						<br>
						<br>
						
			<img class="pic" src="{{asset ('images/' . $recipe . '.jpg' ) }}" alt="{{$recipe}}">
						<br>
						<br>

<a href="/laravel/public/recipes" style="border-bottom: dashed;">Back to Recipelist</a>
<br>
<br>
<br>
<br>
<div class="commentbox">
<h1>Please add a comment on this recipe</h1>
<br>

@if(Auth::check())
<div class="actionbox">
<form action="{{route('commentrecipe', [$id] )}}" method="POST"> 
	{{csrf_field()}}
	<input type="hidden" name="recipes_id" value="{{ $id }}">
          <div class="form-group" style="width:50%; position:relative">                          
          <textarea name="comment"></textarea>
          <br>
          <br>
		  <input type="submit" class="btn btn-primary" value="submit"> 
		  <br>
		  <br>
        </div>
    </form>  
 </div>

@foreach($comments as $comment)

<p><b>{{$comment['name']}}:</b></p>
<p>{{$comment['comment']}}</p>
<a href="{{route('delete', $comment['id'] )}}">
<button type="submit" class="btn">Delete comment</button>
</a>
<br>
<br>
@endforeach
@else
</div>
@foreach($comments as $comment)

<p>{{$comment['name']}}</p>
<br>
<p>{{$comment['comment']}}</p>

@endforeach
@endif

@endsection
