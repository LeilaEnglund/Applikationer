@extends('layouts.app')
@section('content')
<div class="div3">
						<br>
						<br>
						<h2>{{ $recipe }}</h2>
						<br>

			
			<ul id="navcontainer"><li>{{ $ingrediens }}</li></ul>
			
						
						<br>
						<br>
						<h2>Description:</h2>
						<br>
			{{ $description }}
						<br>
						<br>
						
			<img class="pic" src="{{asset ('images/' . $recipe . '.jpg' ) }}" alt="{{$recipe}}">
						<br>
						<br>

<a href="/laravel/public/recipes" style="border-bottom: dashed;">Back to Recipelist</a>
<br>
<br>
<br>
<br>
<div class="commentbox">
<h1>Please add a comment on this recipe</h1>
<br>

@if(Auth::check())
    <div class="actionBox">
    	<form id="recipe_comment_form" action="{{route('commentrecipe', [$id] )}}"  method="POST">
    	{{csrf_field()}}
      <input type ="hidden" name="recipes_id" value="{{ $id }}">
      <p>Write a comment</p>        
          <div class="form-group">                             
              <textarea name="comment" id="comment"></textarea>
              <br>
              <br>
              <input type="Submit" class="btn" value="Submit">
              <br>

          </div>
        </form> 
        <div id="comment_placeholder"></div> 

	</div>

</div>

  <hr>
{{--@foreach($comments as $comment)

	<p data-id="{{$comment['user_id']}}"> {{$comment['name']}}</p>
	<p> {{$comment['comment']}}</p> 

@if (Auth::user() && (Auth::user()->id == $comment['user_id']))
<div class="remove_comment">


    <a href="{{route('delete', $comment['id'] )}}">
      <button type="submit" class="btn">Delete</button>
    </a>

</div>
@endif
<hr>
--}}
@else
	<div class="actionBox">
        <div id="comment_placeholder"></div>       
	</div>

  <hr>

@endif


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>


    let load_comments = function()
	{	//Ajax anrop hämtar kommentarerna från route 
		$.get({{ $id }} +  '/comment',  {recipe_id: {{$id}}},function(comments_data)
		{
			console.error(comments_data);
			let comments = comments_data.map( (comment) => {

let response = '<div data-id="' + comment.id + '">';

	response += '<br>' + '<b>' + comment.name + '</b>' + '<p>' + comment.comment + '</p>' ;

//endast inloggad användare kan radera 
 if (comment.delete_permission) {
	response +=

	 '<button class="btn remove_comment">Delete</button>';
	}

				return response + '</div>';
			});

			$('#comment_placeholder').html(comments);
		});
	};

	$(document).ready(function()
	{
		//submittar kommentaren 
		$('#recipe_comment_form').submit( function(event)
		{
			event.preventDefault();
			//funktion som hämtar kommentaren från textarea och skickar till servern 	
			$.post('{{route('commentrecipe', [$id] )}}',
			{
				'_token': $('#recipe_comment_form input[name=\'_token\']').val(),
				'comment': $('#comment').val(), 
				'recipes_id': {{ $id }}
			}, function(data)
			{
				if(data=='OK')
				{

					$('#comment').val('');
					load_comments();

				}
				else
				{
					alert(data);
				}
			});
		});

		load_comments();
		
	});
	//deletar kommentarerna 
	$(document).on('click', '.remove_comment', function()
	{
		var comment_holder = $(this).parent();
		var comment_id_to_delete = comment_holder.attr('data-id');

		$.post('/laravel/public/delete/{{ $id }}',
		{
			delete_id: comment_id_to_delete,
			'_token': $('#recipe_comment_form input[name=\'_token\']').val()
		}, function(data)
		{
			comment_holder.remove();
		});
	});


	
</script>
@endsection

