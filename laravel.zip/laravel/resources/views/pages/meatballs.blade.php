@extends('layouts.app')
@section('content')

<div class="div3">

					<br>
					<br>

					<h2>Meatballs</h2>
						<br>
					<pre>2 tbsp olive oil</pre>
					<pre>150g/5oz onion, finely chopped</pre>
					<pre>1 clove garlic, crushed</pre>
					<pre>900g/2lb freshly minced beef</pre>
					<pre>2 tbsp freshly chopped herbs, such as marjoram, or 1 tbsp rosemary</pre>
					<pre>1 free-range egg, beaten</pre>
					<pre>salt and freshly ground black pepper</pre>
					<pre>3 tbsp olive oil</pre>
						<br>
						<br>

						<h2>Description:</h2>
						<br>
<pre>1. In a medium sized bowl combine ground beef, panko, parsley, allspice,
nutmeg, onion, garlic powder, pepper, salt and egg. Mix until combined.</pre>
						<br>
						<br>
<pre>2. Roll into 12 large meatballs or 20 small meatballs. In a large skillet heat
olive oil and 1 Tablespoon butter. Add the meatballs and cook turning continuously until
brown on each side and cooked throughout. Transfer to a plate and cover with foil.</pre>
						<br>
						<br>
<pre>3. Add 4 Tablespoons butter and flour to skillet and whisk until it turns brown.
Slowly stir in beef broth and heavy cream. Add worchestershire sauce and dijon
mustard and bring to a simmer until sauce starts to thicken. Salt and pepper to taste.</pre>
						<br>
						<br>
<pre>4. Add the meatballs back to the skillet and simmer for another 1-2 minutes.</pre>

						<br>
						<br>
						<img class="pic" src="{{asset ('images/meat.jpg') }}" alt="meatballs ">
						<br>
						<br>

<a href="/laravel/public/recipes">Back to recepies</a>
@endsection