@extends('layouts.app')
@section('content')
<div class="bg2">
<div class="div2">
				<h1 style="font-size: 40px;">Recipe collection:</h1>
				<br>
				<br>
				@foreach ($recipes as $recipe)
				<br>
				<a class="style" style="font-size: 30px;" href="{{ url('/recipes' , $recipe->id)}}"><br>{{$recipe->recipes}}</a>
				
@endforeach
@endsection

</div>
</div>