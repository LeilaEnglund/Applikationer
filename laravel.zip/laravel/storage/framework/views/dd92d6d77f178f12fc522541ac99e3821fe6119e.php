<?php $__env->startSection('content'); ?>
<div class="bg2">
<div class="div2">
				<h1 style="font-size: 40px;">Recipe collection:</h1>
				<br>
				<br>
				<?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<br>
				<a class="style" style="font-size: 30px;" href="<?php echo e(url('/recipes' , $recipe->id)); ?>"><br><?php echo e($recipe->recipes); ?></a>
				
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

</div>
</div>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>