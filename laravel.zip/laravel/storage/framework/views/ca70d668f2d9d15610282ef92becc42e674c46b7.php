<?php $__env->startSection('content'); ?>

<div class="bg">
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<p class="intro"><br></p>
				<p class="intro"><br></p>
					<p class="intro" style="font-size: 40px">Welcome to My Recipes</p>
					<p class="intro">The perfect page for finding your favorite recipes</p>
					<p class="intro"><br></p>
					<p class="intro"><b>Have a look at the menu of the month: <a href="/laravel/public/calendar">Calendar</a></b></p>
					<p class="intro"><br></p>
					<p class="intro"><br></p>
					<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				<br>
				<br>	
				<br>
				<br>
				<br>
				<br>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>