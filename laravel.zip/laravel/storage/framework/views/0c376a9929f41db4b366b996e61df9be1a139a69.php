<?php $__env->startSection('content'); ?>

<div class="div3">
						<br>
						<br>
						<h2><?php echo e($recipe); ?></h2>
						<br>

			
			<ul id="navcontainer"><li><?php echo e($ingrediens); ?></li></ul>
			
						
						<br>
						<br>
						<h2>Description:</h2>
						<br>
			<?php echo e($description); ?>

						<br>
						<br>
						
			<img class="pic" src="<?php echo e(asset ('images/' . $recipe . '.jpg' )); ?>" alt="<?php echo e($recipe); ?>">
						<br>
						<br>

<a href="/laravel/public/recipes" style="border-bottom: dashed;">Back to Recipelist</a>
<br>
<br>
<br>
<br>
<div class="commentbox">
<h1>Please add a comment on this recipe</h1>
<br>

<?php if(Auth::check()): ?>
<div class="actionbox">
<form action="<?php echo e(route('commentrecipe', [$id] )); ?>" method="POST"> 
	<?php echo e(csrf_field()); ?>

	<input type="hidden" name="recipes_id" value="<?php echo e($id); ?>">
          <div class="form-group" style="width:50%; position:relative">                          
          <textarea name="comment"></textarea>
          <br>
          <br>
		  <input type="submit" class="btn btn-primary" value="submit"> 
		  <br>
		  <br>
        </div>
    </form>  
 </div>

<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p><b><?php echo e($comment['name']); ?>:</b></p>
<p><?php echo e($comment['comment']); ?></p>
<a href="<?php echo e(route('delete', $comment['id'] )); ?>">
<button type="submit" class="btn">Delete comment</button>
</a>
<br>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
</div>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<p><?php echo e($comment['name']); ?></p>
<br>
<p><?php echo e($comment['comment']); ?></p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>