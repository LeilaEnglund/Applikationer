<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;
use Illuminate\Support\Facades\DB;
use App\Recipe;
use App\User;


class RecipeController extends Controller
{
    
     public function recipe($recipeid){
     	
     	///$recipe = Recipe::where('recipes',$recipename)->get();
    

		$recipe = Recipe::find($recipeid);
		//$comments = Comment::where('recipes_id' , $recipeid)->get();
		$dispaycomments = array();

		/*foreach ($comments as $comment) {

		$user = User::find($comment->user_id);	
		$displaycomments[] = ['comment' => $comment->comment,'name' => $user->name, 'id' => $comment->id, 'user_id' => $comment->user_id];
		//$displaycomments['username'] = $user->name;
		}
		//$displaycomments = collect($displaycomments);
*/
		//return $comments;
    	//return $recipe->recipes; //view('pages.recipe', $recipe);
    	return view('pages.recipe', ['recipe' => $recipe->recipes, 'ingrediens' => $recipe->ingrediens, 'description' => $recipe->description,'id' => $recipe->id ]);
    }

}
