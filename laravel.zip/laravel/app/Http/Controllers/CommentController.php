<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Recipe;
use \App\Comment;
use Auth;

class CommentController extends Controller
{
 
   public function store(Recipe $recipe)
 
   {
       
       $comment = Comment::create([

        'comment' => request('comment'),
        'recipes_id' => request('recipes_id'),
        'user_id' => Auth::user()->id
       ]

     );
  
  return back();
 
   }

   public function delete($id){

    $comment = Comment::find($id);

    if (Auth::user() && (Auth::user()->id == $comment->user_id)) {
    Comment::where('id',$id)->delete();
    return back();
  }else{
  return 'you dont have permission';
  }
}

}
